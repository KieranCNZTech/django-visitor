from setuptools import setup

setup(install_requires=['django'])
